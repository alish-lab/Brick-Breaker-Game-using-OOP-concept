# Brick Breaker Game

A classic Brick Breaker game implemented in Java. Features multiple levels, player registration/login, and two-player mode.

## Features
- Multiple levels with different brick types
- Player registration and login
- Two-player mode
- Score tracking

## How to Build and Run
1. Open the project in NetBeans (or any Java IDE).
2. Make sure you have Java installed (JDK 8 or higher).
3. Build and run the `BrickBreakerGame.java` file located in `src/brickbreakergame/`.

## Resources
- Images are located in `res/images/`
- Database file: `src/Database11.accdb`

## Credits
- Developed by [Alishba] 