
package brickbreakergame;

import Entity.PlasticBrick;
import Entity.Brick;
import Entity.Paddle;
import Entity.Ball;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyListener;

public class LevelOne extends Level {
    private GamePanel gp;
    private int row;
    private int col;
    private KeyHandler keyH;
    
    private Paddle paddle;
    private Ball ball;
    private int score = 0;
    private boolean levelEnd = false;
    private boolean gameOver = false;
    private Brick[][] map;

    public LevelOne(GamePanel gp, int row, int col) {
        this.gp = gp;
        this.row = row;
        this.col = col;
         System.out.println("LevelOne constructor called"); // Debugging output
        generateLevel();
    }

    @Override
    public void generateLevel() {
        map = new Brick[row][col];

        keyH = new KeyHandler();
        paddle = new Paddle(gp, keyH);
        ball = new Ball(gp);

        // Create an inverse pyramid pattern
        for (int i = 0; i < row; i++) {
            for (int j = i; j < col - i; j++) {
                int x = j * getBrickWidth() + 135;
                int y = i * getBrickHeight() + 24;
                map[i][j] = new PlasticBrick(gp, x, y);
            }
        }
    }

    @Override
    public Brick[][] getMap() {
        return map;
    }

      @Override
    public boolean nextLevelExists() {
        return true;
    }

    @Override
    public Level getNextLevel() {
        return new LevelTwo(gp, 5, 15);
    }


    
    @Override
    public void draw(Graphics2D g) {
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[0].length; j++) {
                if (map[i][j] != null ) {
                    map[i][j].draw(g);
                }
            }
        }
    }

    @Override
    public int getBrickWidth() {
        return gp.getTileSize();
    }

    @Override
    public int getBrickHeight() {
        return gp.getTileSize() / 2;
    }

    @Override
    public void setBrickValue(int value, int row, int col) {
        if (row >= 0 && row < map.length && col >= 0 && col < map[0].length) {
            if (map[row][col] != null) {
                map[row][col].breakBrick();
            }
        }
    }

    @Override
    public boolean areAllBricksBroken() {
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[0].length; j++) {
                if (map[i][j] != null && !map[i][j].isBroken()) {
                    return false;
                }
            }
        }
        return true;
    }
  
    
}

