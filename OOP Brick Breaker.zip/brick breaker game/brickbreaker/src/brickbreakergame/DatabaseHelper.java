package brickbreakergame;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseHelper {
    
    private static final String URL = "jdbc:ucanaccess://C:\\Users\\Home1\\Documents\\brickbreaker2 (1)\\BrickBreakerMS.accdb";
    private static final String USER = "yourUsername";
    private static final String PASSWORD = "yourPassword";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static int getUserLevel(int userId) {
        String query = "SELECT currentLevel FROM Table1 WHERE userId = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("currentLevel");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 1; // Default to level 1 if not found
    }

    public static void updateUserLevel(int userId, int level) {
        String query = "INSERT INTO Table1 (userId, currentLevel) VALUES (?, ?) " +
                       "ON DUPLICATE KEY UPDATE currentLevel = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, level);
            stmt.setInt(3, level);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}