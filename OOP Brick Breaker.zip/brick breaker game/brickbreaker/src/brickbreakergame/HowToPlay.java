package brickbreakergame;
    
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HowToPlay extends JFrame {

    public HowToPlay() {
        // Set up the frame
        setTitle("How to Play Brick Breaker");
        setSize(600, 400);
        setLocationRelativeTo(null); // Center the window
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close this window only
        setResizable(false);

        // Create a container for the content
        Container container = getContentPane();
        container.setLayout(new BorderLayout());
        container.setBackground(Color.BLACK);
        

        // Create a panel for the text
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BorderLayout());
        textPanel.setBackground(Color.BLACK);
        textPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        

        // Instructions text
        JTextArea instructionsText = new JTextArea();
        instructionsText.setText(
                "Brick Breaker Game Instructions:\n\n" +
                "1. Use the left and right arrow keys to move the paddle.\n" +
                "2. Your objective is to break all the bricks by bouncing the ball off the paddle.\n" +
                "3. If the ball falls below the paddle, you lose a life.\n" +
                "4. The game ends when you break all the bricks or lose all your lives.\n\n" +
                "Good luck and have fun!"
        );
        instructionsText.setFont(new Font("Arial", Font.PLAIN, 16));
        instructionsText.setForeground(Color.WHITE);
        instructionsText.setBackground(Color.BLACK);
        instructionsText.setEditable(false);
        instructionsText.setLineWrap(true);
        instructionsText.setWrapStyleWord(true);

        // Add a scroll pane in case the text overflows
        JScrollPane scrollPane = new JScrollPane(instructionsText);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        textPanel.add(scrollPane, BorderLayout.CENTER);

        // Add the text panel to the container
        container.add(textPanel, BorderLayout.CENTER);

        // Create a panel for the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(Color.BLACK);

        // Close button
        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBackground(new Color(30, 144, 255)); // Dodger Blue color
        closeButton.setFocusPainted(false);
        closeButton.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the instructions window
            }
        });

        buttonPanel.add(closeButton);

        // Add the button panel to the container
        container.add(buttonPanel, BorderLayout.SOUTH);

        // Make the frame visible
        setVisible(true);
    }

//    public static void main(String[] args) {
//        // Test the HowToPlay window
//        SwingUtilities.invokeLater(new Runnable() {
//            @Override
//            public void run() {
//                new HowToPlay();
//            }
//        });
//    }
}