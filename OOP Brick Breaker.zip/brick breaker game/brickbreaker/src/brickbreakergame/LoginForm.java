package brickbreakergame;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import javax.imageio.ImageIO;
import javax.swing.border.TitledBorder;

public class LoginForm extends JFrame implements ActionListener {
    // Components of the form
    private Container container;
    private JLabel titleLabel;
    private JTextField userText;
    private JPasswordField passwordText;
    private JButton loginButton;
    private JLabel statusLabel;
    
    private final int tileSize = 32; // Size of one tile in pixels
    private final int maxScreenCol = 24; // Maximum number of columns
    private final int maxScreenRow = 18; // Maximum number of rows
    private final int screenWidth = tileSize * maxScreenCol; // 768 pixels
    private final int screenHeight = tileSize * maxScreenRow; // 576 pixels

    // Database connection
    private Connection connection;

    public LoginForm() {
        setTitle("Login Form");
        setBounds(300, 90, screenWidth, screenHeight);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null); // Center window

        
//         Load the background image
        Image backgroundImage = null;
        try {
             backgroundImage = ImageIO.read(getClass().getResourceAsStream("/images/bg2.jpeg"));
            //backgroundImage = ImageIO.read(new File("//C:\\Users\\nabih\\OneDrive - Higher Education Commission\\Documents\\NetBeansProjects\\BrickBreakerGame\\src\\brickbreakergame\\797f6c526a283000468c5620f0c5027b.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

//         Set the custom background panel
        BackgroundPanel backgroundPanel = new BackgroundPanel(backgroundImage);
        setContentPane(backgroundPanel);
        
        
        container = getContentPane();
        container.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        
        Color buttonBackgroundColor = new Color(51,204,255); // Dodger Blue

        titleLabel = new JLabel("Login");
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 30));
        titleLabel.setForeground(Color.WHITE); // Set title color to white
        gbc.gridx = 0;
        gbc.gridy = 0; // Set the position to the top row
        gbc.gridwidth = 2; // Span across two columns
        gbc.anchor = GridBagConstraints.CENTER; // Align at the center
        gbc.insets = new Insets(20, 0, 20, 0); // Add some top and bottom padding
        container.add(titleLabel, gbc);
        
        // Username field
        userText = new JTextField();
        userText.setOpaque(false); // Make transparent
        userText.setForeground(Color.WHITE); // Set text color to white
        //userText.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.WHITE), /* Border color*/"Username", /Title text/TitledBorder.DEFAULT_JUSTIFICATION, /* Title position*/TitledBorder.DEFAULT_POSITION, /* Title location*/new Font("Arial", Font.BOLD, 12), /* Title font*/Color.WHITE /* Title color*/));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.insets = new Insets(10, 250, 10, 250);
        container.add(userText, gbc);

        // Password field
        passwordText = new JPasswordField();
        passwordText.setOpaque(false); // Make transparent
        passwordText.setForeground(Color.WHITE); // Set text color to white
      //  passwordText.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.WHITE), /Border color/"Password", /Title text/TitledBorder.DEFAULT_JUSTIFICATION, /* Title position*/ TitledBorder.DEFAULT_POSITION, /* Title location*/ new Font("Arial", Font.BOLD, 12), /* Title font*/Color.WHITE /* Title color*/));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.insets = new Insets(10, 250, 10, 250);
        container.add(passwordText, gbc);

        // Login button
        loginButton = new JButton("Login");
        loginButton.addActionListener(this);
        loginButton.setPreferredSize(new Dimension(100, 40)); // Set button size
        customizeButton(loginButton, buttonBackgroundColor, Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0.5;
        gbc.insets = new Insets(10, 200, 10, 200);
        container.add(loginButton, gbc);

        // Status label
        statusLabel = new JLabel("", SwingConstants.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.insets = new Insets(10, 10, 10, 10);
        container.add(statusLabel, gbc);

        setVisible(true);

        // Establish database connection
        establishConnection();
    }

    // Method to establish database connection
    private void establishConnection() {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            //C:\Users\Home1\Documents\brickbreaker2 (1)\BrickBreakerMS.accdb
            connection = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Home1\\Documents\\brickbreaker2 (1)\\BrickBreakerMS.accdb");
            statusLabel.setText("");
        } catch (Exception e) {
            statusLabel.setText("Database connection failed!");
            e.printStackTrace();
        }
    }

    // Method to handle login action
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            String username = userText.getText();
            String password = new String(passwordText.getPassword());

            if (authenticate(username, password)) {
                new GameMenu(); 
                dispose();
            } else {
                statusLabel.setText("Wrong Username or Password"); // Display error message
            }
        }
    }

    private boolean authenticate(String username, String password) {
        try {
            String query = "SELECT * FROM Table1 WHERE username = ? AND password = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();

            return rs.next(); // Returns true if a matching record is found
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void customizeButton(JButton button, Color backgroundColor, Color textColor) {
        button.setBackground(backgroundColor);
        button.setForeground(textColor);
        button.setFont(new Font("Arial", Font.BOLD, 18));
        button.setFocusPainted(false); // Remove the focus painting
        button.setBorder(BorderFactory.createLineBorder(Color.BLACK)); // Optional: Add a black border for better visibility
    }
}