package brickbreakergame;

import Entity.Brick;
import Entity.Paddle;
import Entity.Ball;
import java.awt.Graphics2D;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TwoPlayerGamePanel extends GamePanel{
    private Paddle paddle2 = new Paddle(this, keyH);
    private Ball ball2 = new Ball(this);
    private int score2;
    public TwoPlayerGamePanel() {
        setPreferredSize(new Dimension(screenWidth, screenHeight));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(keyH);
        setGameState(getPlayState());
        getPaddle().setX(100);
        paddle2.setX(500);
        getBall().setX(100);
        ball2.setX(500);
    }
    @Override
    public void startGameThread(){
        this.requestFocusInWindow();
        gameThread = new Thread(this);
        gameThread.start();
    }
    @Override
    public void repaintPanel() {
        repaint();
    }

    @Override
    public void run() {
        double drawInterval = 1000000000 / fps;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;
        int drawCount = 0;

        while (gameThread != null) {
            currentTime = System.nanoTime();
            delta += (currentTime - lastTime) / drawInterval;
            timer += (currentTime - lastTime);
            lastTime = currentTime;

            if (delta >= 1) {
                if (getGameState() == getPlayState()) {
                    update();
                }
                repaint();
                delta--;
                drawCount++;
            }

            if (timer >= 1000000000) {
                System.out.println("FPS: " + drawCount);
                drawCount = 0;
                timer = 0;
            }

            if (keyH.spacePressed) {
                if (getGameState() == getPlayState()) {
                    setGameState(getPauseState());
                    super.showPauseScreen();
                } else if (getGameState() == getPauseState()) {
                    resumeGame();
                }
                keyH.spacePressed = false;
            }

            if (getLevelEnd()) {
                setGameState(getLevelEndState());
                showLevelEndScreen();
                break;
            }

            if (getGameOver()) {
                setGameState(getLevelFailedState());
                showLevelFailedScreen();
                break;
            }
        }
    }
    public void update() {
        if (!getGameOver() && !getLevelEnd()) {
            paddle.update();
            ball.update();
            paddle2.update();
            ball2.update();

            // Check collision between ball and paddle
            if (ball.getBounds().intersects(paddle.getBounds())) {
                ball.setBallYdir(-ball.getBallYdir());
            }
            if (ball2.getBounds().intersects(paddle2.getBounds())) {
                ball2.setBallYdir(-ball2.getBallYdir());
            }

            // Check collision between ball and bricks
            for (int i = 0; i < getCurrentLevel().getMap().length; i++) {
                for (int j = 0; j < getCurrentLevel().getMap()[0].length; j++) {
                    Brick brick = getCurrentLevel().getMap()[i][j];
                    if (brick != null && !brick.isBroken()) {
                        if (ball.getBounds().intersects(brick.getBounds())) {
                            brick.breakBrick();
                            score += 5;
                            Rectangle intersection = ball.getBounds().intersection(brick.getBounds());
                            if (intersection.getWidth() > intersection.getHeight()) {
                                ball.setBallYdir(-ball.getBallYdir());
                            } else {
                                ball.setBallXdir(-ball.getBallXdir());
                            }
                            repaintPanel(); // Redraw the panel after collision
                            return; // Return after detecting the collision
                        }
                        if (ball2.getBounds().intersects(brick.getBounds())) {
                            brick.breakBrick();
                            score2 += 5;
                            Rectangle intersection = ball2.getBounds().intersection(brick.getBounds());
                            if (intersection.getWidth() > intersection.getHeight()) {
                                ball2.setBallYdir(-ball2.getBallYdir());
                            } else {
                                ball2.setBallXdir(-ball2.getBallXdir());
                            }
                            repaintPanel(); // Redraw the panel after collision
                            return; // Return after detecting the collision
                        }
                    }
                }
            }

           if (getCurrentLevel().areAllBricksBroken()) {
                setLevelEnd(true);
            }
        }
        }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        getPaddle().draw(g2);
        paddle2.draw(g2);
        getCurrentLevel().draw(g2);
        getBall().draw(g2);
        ball2.draw(g2);
        
        g.setColor(Color.WHITE);
        g.setFont(new Font("arial", Font.BOLD, 24));
        g.drawString("Score: " + score2, 658, 542);
        
        g.setColor(Color.WHITE);
        g.setFont(new Font("arial", Font.BOLD, 24));
        g.drawString("Player 1", 30, 492);
        
        g.setColor(Color.WHITE);
        g.setFont(new Font("arial", Font.BOLD, 24));
        g.drawString("Player 2", 658, 492);

        if (getGameOver()) {
            drawGameOver(g2);
        }
    }

    private void drawGameOver(Graphics2D g2) {
        String message = "Game Over";
        Font font = new Font("Arial", Font.BOLD, 36);
        FontMetrics metrics = getFontMetrics(font);

        g2.setColor(Color.RED);
        g2.setFont(font);
        g2.drawString(message, (screenWidth - metrics.stringWidth(message)) / 2, screenHeight / 2);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle any button clicks or other actions
    }
}
