package brickbreakergame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class MainMenu extends JFrame implements ActionListener {
    private JButton registerButton;
    private JButton loginButton;
    private JButton guestButton;
    
    private final int tileSize = 32; // Size of one tile in pixels
    private final int maxScreenCol = 24; // Maximum number of columns
    private final int maxScreenRow = 18; // Maximum number of rows
    private final int screenWidth = tileSize * maxScreenCol; // 768 pixels
    private final int screenHeight = tileSize * maxScreenRow; // 576 pixels

    public MainMenu() {
        setTitle("Main Menu");
        setBounds(300, 90, screenWidth, screenHeight);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null); // Center window
        
        //         Load the background image
        Image backgroundImage = null;
        try {
            backgroundImage = ImageIO.read(getClass().getResourceAsStream("/images/bg2.jpeg"));
           // backgroundImage = ImageIO.read(new File("//C:\\Users\\nabih\\OneDrive - Higher Education Commission\\Documents\\NetBeansProjects\\BrickBreakerGame\\src\\brickbreakergame\\797f6c526a283000468c5620f0c5027b.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

//         Set the custom background panel
        BackgroundPanel backgroundPanel = new BackgroundPanel(backgroundImage);
        setContentPane(backgroundPanel);
        
        
        Container container = getContentPane();
        container.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        
        JLabel titleLabel = new JLabel("Main Menu");
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 30));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = -1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.insets = new Insets(20, 0, 20, 0); // Padding for title
        container.add(titleLabel, gbc);

        // Define custom colors
        Color buttonBackgroundColor = new Color(30, 144, 255); // Dodger Blue

        // Register button
        registerButton = new JButton("Register");
        registerButton.addActionListener(this);
        registerButton.setPreferredSize(new Dimension(150, 40)); // Set button size
        customizeButton(registerButton, buttonBackgroundColor, Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 70, 10, 70); // Horizontal padding for centering
        container.add(registerButton, gbc);

        // Login button
        loginButton = new JButton("Login");
        loginButton.addActionListener(this);
        loginButton.setPreferredSize(new Dimension(150, 40)); // Set button size
        customizeButton(loginButton, buttonBackgroundColor, Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 70, 10, 70); // Horizontal padding for centering
        container.add(loginButton, gbc);

        // Play as Guest button
        guestButton = new JButton("Play as Guest");
        guestButton.addActionListener(this);
        guestButton.setPreferredSize(new Dimension(150, 40)); // Set button size
        customizeButton(guestButton, buttonBackgroundColor, Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 70, 10, 70); // Horizontal padding for centering
        container.add(guestButton, gbc);

        setVisible(true);
    }
    
    private void customizeButton(JButton button, Color backgroundColor, Color textColor) {
        button.setBackground(backgroundColor);
        button.setForeground(textColor);
        button.setFont(new Font("Calibri", Font.BOLD, 24));
        button.setFocusPainted(false); // Remove the focus painting
        button.setBorder(BorderFactory.createLineBorder(Color.BLACK)); // Optional: Add a black border for better visibility
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == registerButton) {
            // Open registration form
            new RegistrationForm();
            
        } else if (e.getSource() == loginButton) {
            // Open login form
            new LoginForm();
            
        } else if (e.getSource() == guestButton) {
            // Directly open game menu for guests
            new GameMenu();
        }
        dispose();
    }

//    public static void main(String[] args) {
//        SwingUtilities.invokeLater(() -> new MainMenu());
//    }
}