
package brickbreakergame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.imageio.ImageIO;

public class LevelMenu extends JFrame implements ActionListener {

    private GamePanel gp;
    private JButton levelButton1, levelButton2, levelButton3, backButton;

    private final int tileSize = 32;
    private final int maxScreenCol = 24;
    private final int maxScreenRow = 18;
    private final int screenWidth = tileSize * maxScreenCol; // 768 pixels
    private final int screenHeight = tileSize * maxScreenRow; // 576 pixels

    private JPanel levelPanel;

    private static final int NUM_LEVELS = 3;

    public LevelMenu() {
        setTitle("Select Level");
        setBounds(300, 90, screenWidth, screenHeight);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        // Background
        Image backgroundImage = null;
        try {
            backgroundImage = ImageIO.read(getClass().getResourceAsStream("/images/bg2.jpeg"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        BackgroundPanel backgroundPanel = new BackgroundPanel(backgroundImage);
        setContentPane(backgroundPanel);

        levelPanel = new JPanel(new GridBagLayout());
        levelPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Level buttons
        levelButton1 = createLevelButton("Level 1", 1);
        levelButton2 = createLevelButton("Level 2", 2);
        levelButton3 = createLevelButton("Level 3", 3);

        gbc.gridx = 0;
        gbc.gridy = 0;
        levelPanel.add(levelButton1, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        levelPanel.add(levelButton2, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        levelPanel.add(levelButton3, gbc);

        // Back button
        backButton = new JButton("Back to Menu");
        backButton.setPreferredSize(new Dimension(150, 40));
        customizeButton(backButton, new Color(51, 204, 255), Color.WHITE);
        backButton.addActionListener(this);
        gbc.gridx = 1;
        gbc.gridy = 1;
        levelPanel.add(backButton, gbc);

        add(levelPanel);
        setVisible(true);
    }

    private JButton createLevelButton(String title, int levelNumber) {
        JButton button = new JButton(title);
        button.setPreferredSize(new Dimension(120, 40));
        customizeButton(button, new Color(34, 139, 34), Color.WHITE); // Forest green color
        button.addActionListener(this);
        return button;
    }

    private void customizeButton(JButton button, Color backgroundColor, Color textColor) {
        button.setBackground(backgroundColor);
        button.setForeground(textColor);
        button.setFont(new Font("Arial", Font.BOLD, 18));
        button.setFocusPainted(false); // Remove the focus painting
        button.setBorder(BorderFactory.createLineBorder(Color.BLACK)); // Optional: Add a black border for better visibility
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == backButton) {
            new GameMenu();
            dispose();
        } else {
            GamePanel game = new GamePanel();
            JFrame jframe = new JFrame();

            jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            jframe.setResizable(false);
            jframe.setTitle("Brick Breaker Game");
            jframe.setLocation(100, 100);

            if (e.getSource() == levelButton1) {
                Level level = new LevelOne(game,6 , 11);
                game.setLevel(level);
            } else if (e.getSource() == levelButton2) {
                Level level = new LevelTwo(game, 5, 15);
                game.setLevel(level);
            } else if (e.getSource() == levelButton3) {
                Level level = new LevelThree(game, 5, 15);
                game.setLevel(level);
            }

            jframe.add(game);
            jframe.pack();
            jframe.setVisible(true);
            game.startGameThread(); // Start the game thread to begin gameplay

            dispose();
        }
    }
}

