
package brickbreakergame;

import Entity.Ball;
import Entity.Brick;
import Entity.Paddle;
import Entity.PlasticBrick;
import Entity.StoneBrick;
import Entity.WoodBrick;
import java.awt.Graphics2D;
import java.awt.event.KeyListener;
import java.util.Random;


public class LevelThree extends Level{
   
    private GamePanel gp;
    private int row;
    private int col;
    private KeyHandler keyH;
    private Paddle paddle;
    private Ball ball;
    private int score = 0;
       private Random random;
    private boolean levelEnd = false;
    private boolean gameOver = false;
    private Brick[][] map;

    public LevelThree(GamePanel gp, int row, int col) {
        this.gp = gp;
        this.row = row;
        this.col = col;
    this.random = new Random();
        generateLevel();
    }

    @Override
    public void generateLevel() {
        map = new Brick[row][col];

        keyH = new KeyHandler();
        paddle = new Paddle(gp, keyH);
        ball = new Ball(gp);


           
              for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            int x = j * getBrickWidth() + 24;
            int y = i * getBrickHeight() + 24;
             if ((i == 0 || i == row - 1 || j == 0 || j == col - 1) && random.nextDouble() < 0.25) {
                map[i][j] = new PlasticBrick(gp, x, y);
            } else if (i % 3 == 0 && j % 5 == 0) {
                map[i][j] = new WoodBrick(gp, x, y);
            } else {
                if (random.nextDouble() < 0.75) { // 50% probability for plastic brick in other positions
                    map[i][j] = new PlasticBrick(gp, x, y);
                } else {
                    map[i][j] = new StoneBrick(gp, x, y);
                }
            }
        }
    }
    }
    
    @Override
    public Brick[][] getMap() {
        return map;
    }

      @Override
    public boolean nextLevelExists() {
        return true;
    }

    @Override
    public Level getNextLevel() {
        return null;
    }


    
    @Override
    public void draw(Graphics2D g) {
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[0].length; j++) {
                if (map[i][j] != null ) {
                    map[i][j].draw(g);
                }
            }
        }
    }

    @Override
    public int getBrickWidth() {
        return gp.getTileSize();
    }

    @Override
    public int getBrickHeight() {
        return gp.getTileSize() / 2;
    }

    @Override
    public void setBrickValue(int value, int row, int col) {
        if (row >= 0 && row < map.length && col >= 0 && col < map[0].length) {
            if (map[row][col] != null) {
                map[row][col].breakBrick();
            }
        }
    }

    @Override
    public boolean areAllBricksBroken() {
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[0].length; j++) {
                if (map[i][j] != null && !map[i][j].isBroken()) {
                    return false;
                }
            }
        }
        return true;
    }
   
}


    


