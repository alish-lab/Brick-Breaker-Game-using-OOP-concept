package brickbreakergame;

import Entity.Brick;
import java.awt.Graphics2D;
import java.awt.event.KeyListener;


public abstract class Level {
    
 protected GamePanel gp;
    public Brick[][] Map;

    public Brick[][] getMap() {
        return Map;
    }   
    
//    public Level(GamePanel gp) {
//        this.gp = gp;
//    }

     public abstract void generateLevel();
    public abstract int getBrickWidth();
    public abstract int getBrickHeight();
    public abstract void setBrickValue(int value, int row, int col);
    public abstract boolean areAllBricksBroken();
    public abstract void draw(Graphics2D g);
   // public abstract KeyListener getKeyHandler();
    
      
    public abstract boolean nextLevelExists();
    public abstract Level getNextLevel();
       

    //public abstract void update();
}


