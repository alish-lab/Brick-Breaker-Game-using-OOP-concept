package brickbreakergame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import Entity.Brick;
import Entity.Paddle;
import Entity.Ball;

public class GameMenu extends JFrame implements ActionListener {
    private JButton playButton;
    private JButton howToPlayButton;
    private JButton exitButton;
    private String username;
    
    private final int tileSize = 32; 
    private final int maxScreenCol = 24; 
    private final int maxScreenRow = 18; 
    private final int screenWidth = tileSize * maxScreenCol; // 768 pixels
    private final int screenHeight = tileSize * maxScreenRow; // 576 pixels

    public GameMenu() {
//        this.username = username;

        setTitle("Game Menu");
        setBounds(300, 90, screenWidth, screenHeight);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null); // Center window

//         Load the background image
        Image backgroundImage = null;
        try {
             backgroundImage = ImageIO.read(getClass().getResourceAsStream("/images/bg2.jpeg"));
            //backgroundImage = ImageIO.read(new File("//C:\\Users\\nabih\\OneDrive - Higher Education Commission\\Documents\\NetBeansProjects\\BrickBreakerGame\\src\\brickbreakergame\\797f6c526a283000468c5620f0c5027b.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

//         Set the custom background panel
        BackgroundPanel backgroundPanel = new BackgroundPanel(backgroundImage);
        setContentPane(backgroundPanel);
        
        
        Container container = getContentPane();
        container.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        
        Color buttonBackgroundColor = new Color(30, 144, 255); // Dodger Blue

        // Play Game button
        playButton = new JButton("Play Game");
        playButton.addActionListener(this);
        playButton.setPreferredSize(new Dimension(100, 40)); // Set button size
        customizeButton(playButton, buttonBackgroundColor, Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 70, 10, 70); // Horizontal padding for centering
        container.add(playButton, gbc);

        // How to Play button
        howToPlayButton = new JButton("How to Play");
        howToPlayButton.addActionListener(this);
        howToPlayButton.setPreferredSize(new Dimension(150, 40)); // Set button size
        customizeButton(howToPlayButton, buttonBackgroundColor, Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 70, 10, 70); // Horizontal padding for centering
        container.add(howToPlayButton, gbc);

        // Exit button
        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);
        exitButton.setPreferredSize(new Dimension(150, 40)); // Set button size
        customizeButton(exitButton, buttonBackgroundColor, Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 70, 10, 70); // Horizontal padding for centering
        container.add(exitButton, gbc);

        setVisible(true);
    }

    private void customizeButton(JButton button, Color backgroundColor, Color textColor) {
        button.setBackground(backgroundColor);
        button.setForeground(textColor);
        button.setFont(new Font("Calibri", Font.BOLD, 24));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(Color.BLACK)); 
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == playButton) {
            new LevelMenu();
            dispose();
        } else if (e.getSource() == howToPlayButton) {
            new HowToPlay();
            dispose();
        } 
        else if  (e.getSource() == exitButton) {
            System.exit(0);
            dispose();
        }
       
        
    }
    
}