package brickbreakergame;

import Entity.Brick;
import Entity.Paddle;
import Entity.Ball;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

public class GamePanel extends JPanel implements Runnable, ActionListener {
    final int originalTileSize = 16;
    final int scale = 3;

    public int tileSize = originalTileSize * scale;
    int maxScreenCol = 16;
    int maxScreenRow = 12;
    public int screenWidth = tileSize * maxScreenCol;
    public int screenHeight = tileSize * maxScreenRow;
    Thread gameThread;
    KeyHandler keyH = new KeyHandler();
    Paddle paddle = new Paddle(this, keyH);
    Ball ball = new Ball(this);
    private Level currentLevel;
    private Image backgroundImage;
    private int gameState;
    private final int playState = 1;
    private final int pauseState = 2;
    private final int levelEndState = 3;
    private final int levelFailedState = 4;
    private boolean levelEnd = false;
    private boolean gameOver = false;
    private JLayeredPane layeredPane;
    private JButton resumeButton;
    private JButton exitButton;
    private JButton restartLevel;
    private JButton nextLevel;
    private boolean allLevelsCompleted = false;

    int fps = 60;
    public int score = 0;

    public GamePanel() {
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true);
        this.addKeyListener(keyH);
        this.setFocusable(true);
        initializeLevels();
        loadImage();
        setFocusTraversalKeysEnabled(false);
        gameState = playState;
        setupUI();
    }

    public void initializeLevels() {      
         currentLevel = new LevelOne(this, 1, 1);
    }

   public void setLevel(Level level) {
        this.currentLevel = level;
        levelEnd = false;
        allLevelsCompleted = false;
        ball.resetBall();
        paddle.resetpaddle();
        gameState = playState; // Ensure game state is set to play when a level is set
    }

    public void startGameThread() {
        this.requestFocusInWindow();
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void repaintPanel() {
        repaint();
    }

    @Override
public void run() {
    double drawInterval = 1000000000 / fps;
    double delta = 0;
    long lastTime = System.nanoTime();
    long currentTime;
    long timer = 0;
    int drawCount = 0;

    while (gameThread != null) {
        currentTime = System.nanoTime();
        delta += (currentTime - lastTime) / drawInterval;
        timer += (currentTime - lastTime);
        lastTime = currentTime;

        if (delta >= 1) {
            if (gameState == playState) {
                update();
            }
            repaint();
            delta--;
            drawCount++;
        }

        if (timer >= 1000000000) {
            System.out.println("FPS: " + drawCount);
            drawCount = 0;
            timer = 0;
        }

        if (keyH.spacePressed) {
            if (gameState == playState) {
                gameState = pauseState;
                showPauseScreen();
            } else if (gameState == pauseState) {
                resumeGame();
            }
            keyH.spacePressed = false;
        }
if (levelEnd && !allLevelsCompleted) {
    if (currentLevel.areAllBricksBroken()) {
        if (timer >= 1000000000) { // Check if 1 second has passed
            if (currentLevel.nextLevelExists()) {
                setLevel(currentLevel.getNextLevel());
                levelEnd = false; // Reset the levelEnd flag

                // Reset the ball and paddle
                ball.resetBall();
                paddle.resetpaddle();

                // Update game state
                gameState = playState;

                showNextLevelButton(false); // Hide the next level button
                exitButton.setVisible(false); // Hide the exit button

                timer = 0; // Reset the timer
            } else {
                allLevelsCompleted = true;
                gameState = levelEndState;
                exitButton.setVisible(false); // Hide the exit button
            }
        } else {
            showNextLevelButton(true);
            exitButton.setVisible(false);
        }
    }
}

        if (gameOver) {
            gameState = levelFailedState;
            showLevelFailedScreen();
            break;
        }
    }
}

public void showNextLevelButton(boolean show) {
    nextLevel.setVisible(show);
}

    public void update() {
        if (!gameOver && !levelEnd) {
            paddle.update();
            ball.update();

            // Check collision between ball and paddle
            if (ball.getBounds().intersects(paddle.getBounds())) {
                ball.setBallYdir(-ball.getBallYdir());
            }

            // Check collision between ball and bricks
            for (int i = 0; i < currentLevel.getMap().length; i++) {
                for (int j = 0; j < currentLevel.getMap()[0].length; j++) {
                    Brick brick = currentLevel.getMap()[i][j];
                    if (brick != null && !brick.isBroken()) {
                        if (ball.getBounds().intersects(brick.getBounds())) {
                            brick.breakBrick();
                            score += 5;
                            Rectangle intersection = ball.getBounds().intersection(brick.getBounds());
                            if (intersection.getWidth() > intersection.getHeight()) {
                                ball.setBallYdir(-ball.getBallYdir());
                            } else {
                                ball.setBallXdir(-ball.getBallXdir());
                            }
                            repaintPanel(); // Redraw the panel after collision
                            return; // Return after detecting the collision
                        }
                    }
                }
            }

           if (currentLevel.areAllBricksBroken()) {
                levelEnd = true;
            }
        }
        }
    

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        // Drawing background image
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, screenWidth, screenHeight, null);
        }

        // Drawing paddle
        paddle.draw(g2);

        // Drawing map
        currentLevel.draw(g2);

        // Drawing ball
        ball.draw(g2);

        // Draw Lives 
        int heartX = 35;
        BufferedImage heartImage = ball.getHeartImage();
        for (int i = 0; i < ball.getLives(); i++) {
            g2.drawImage(heartImage, heartX, 505, 20, 20, null);
            heartX += 25;
        }

        // Drawing score
        g.setColor(Color.WHITE);
        g.setFont(new Font("arial", Font.BOLD, 24));
        g.drawString("Score: " + score, 30, 542);

        // Drawing borders
        g2.setColor(Color.WHITE);
        g2.fillRect(0, 0, 10, screenHeight);
        g2.fillRect(0, 0, screenWidth, 10);
        g2.fillRect(screenWidth - 10, 0, 10, screenHeight);

        // Handling game over
        if (gameOver) {
            g.setColor(Color.RED);
            g.setFont(new Font("serif", Font.BOLD, 30));
            g.drawString("Game Over!", 320, 250);
            g.setColor(Color.RED);
            g.setFont(new Font("serif", Font.BOLD, 30));
            g.drawString("Score: " + score, 340, 290);
        }

        if (allLevelsCompleted) {
    g2.setColor(Color.GREEN);
    g2.setFont(new Font("Serif", Font.BOLD, 30));
    g2.drawString("You have Completed all the levels", 320, 250);
       } 
        
        

        if (gameState == pauseState) {
            drawPauseScreen(g2);
        } else if (gameState == levelEndState) {
            drawLevelEndScreen(g2);
        } else if (gameState == levelFailedState) {
            drawLevelFailedScreen(g2);
        }
    }

    public void drawPauseScreen(Graphics2D g2) {
        g2.setColor(Color.BLUE);
        g2.fillRect(259, 150, 250, 250);
        g2.setColor(Color.white);
        g2.setStroke(new BasicStroke(10));
        g2.drawRect(259, 150, 250, 250);

        String text = "GAME PAUSED";
        int length = (int) g2.getFontMetrics().getStringBounds(text, g2).getWidth();
        int x = (screenWidth / 2) - (length / 2) - 22;
        int y = 210;
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("serif", Font.BOLD, 30));
        g2.drawString(text, x, y);

        resumeButton.setVisible(true);
        exitButton.setVisible(true);
        restartLevel.setVisible(true);
    }

    public void drawLevelFailedScreen(Graphics2D g2) {
        g2.setColor(Color.BLUE);
        g2.fillRect(259, 200, 250, 250);
        g2.setColor(Color.white);
        g2.setStroke(new BasicStroke(10));
        g2.drawRect(259, 200, 250, 250);

        String text = "Level Failed!";
        int length = (int) g2.getFontMetrics().getStringBounds(text, g2).getWidth();
        int x = (screenWidth / 2) - (length / 2) - 20;
        int y = screenHeight / 2;
        g2.setColor(Color.RED);
        g2.setFont(new Font("serif", Font.BOLD, 30));
        g2.drawString(text, x, y);

        resumeButton.setVisible(false);
        exitButton.setAlignmentY(screenHeight / 2 + 30);
        exitButton.setVisible(true);
    }

    protected void showPauseScreen() {
        gameState = pauseState;
        resumeButton.setVisible(true);
        exitButton.setVisible(true);
        restartLevel.setVisible(true);
    }

    protected void resumeGame() {
        gameState = playState;
        resumeButton.setVisible(false);
        exitButton.setVisible(false);
        restartLevel.setVisible(false);
    }

    public void restartLevel() {
        score = 0;
        levelEnd = false;
        gameOver = false;
        ball.resetBall();
        paddle.resetpaddle();
        getCurrentLevel();
        gameState = playState;
        resumeButton.setVisible(false);
        exitButton.setVisible(false);
        restartLevel.setVisible(false);
    }

    protected void showLevelEndScreen() {
        gameState = levelEndState;
        resumeButton.setVisible(false);
        exitButton.setVisible(false);
    }

    protected void showLevelFailedScreen() {
        gameState = levelFailedState;
        resumeButton.setVisible(false);
        exitButton.setVisible(true);
        restartLevel.setVisible(true);
    }

    public void drawLevelEndScreen(Graphics2D g2) {
        String text = "Level Complete!";
        int length = (int) g2.getFontMetrics().getStringBounds(text, g2).getWidth();
        int x = (screenWidth / 2) - (length / 2);
        int y = screenHeight / 2;
        g2.setColor(Color.GREEN);
        g2.setFont(new Font("serif", Font.BOLD, 30));
        g2.drawString(text, x, y);

        resumeButton.setVisible(false);
        nextLevel.setVisible(false);
        exitButton.setVisible(false);
    }

    @Override
public void actionPerformed(ActionEvent e) {
    if (e.getSource() == resumeButton) {
        resumeGame();
    } else if (e.getSource() == exitButton) {
        exitLevel();
    } else if (e.getSource() == restartLevel) {
        restartLevel();
    } else if (e.getSource() == nextLevel) {
        if (currentLevel.nextLevelExists()) {
            setLevel(currentLevel.getNextLevel());
            ball.resetBall();
            paddle.resetpaddle();
            gameState = playState;
            nextLevel.setVisible(false);
        } else {
            allLevelsCompleted = true;
            gameState = levelEndState;
            nextLevel.setVisible(false);
        }
    }
}

    private void exitLevel() {
        GameMenu gm = new GameMenu();
      // dispose();
       // gm.GameMenu();
     //   System.exit(0); // Implement level exit logic here
    }

    private void loadImage() {
        try {
            backgroundImage = ImageIO.read(getClass().getResource("/images/bg6.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setupUI() {
        layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(screenWidth, screenHeight));
        layeredPane.setLayout(null);

        resumeButton = new JButton("Resume Game");
        resumeButton.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 15));
        resumeButton.setSize(150, 50);
        resumeButton.setBackground(Color.white);
        resumeButton.setLocation((screenWidth - resumeButton.getWidth()) / 2, screenHeight / 2 - 50);
        resumeButton.addActionListener(this);
        resumeButton.setVisible(false);
        layeredPane.add(resumeButton, JLayeredPane.PALETTE_LAYER);

        exitButton = new JButton("Exit Level");
        exitButton.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 15));
        exitButton.setSize(150, 50);
        exitButton.setLocation((screenWidth - exitButton.getWidth()) / 2, screenHeight / 2 + 10);
        exitButton.addActionListener(this);
        exitButton.setVisible(false);
        layeredPane.add(exitButton, JLayeredPane.PALETTE_LAYER);

        restartLevel = new JButton("Restart Level");
        restartLevel.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 15));
        restartLevel.setSize(150, 50);
        restartLevel.setLocation((screenWidth - exitButton.getWidth()) / 2, screenHeight / 2 + 60);
        restartLevel.addActionListener(this);
        restartLevel.setVisible(false);
        layeredPane.add(restartLevel, JLayeredPane.PALETTE_LAYER);

        nextLevel = new JButton("Next Level");
        nextLevel.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 15));
        nextLevel.setSize(150, 50);
        nextLevel.setLocation((screenWidth - exitButton.getWidth()) / 2, screenHeight / 2 + 60);
        nextLevel.addActionListener(this);
        nextLevel.setVisible(false);
        layeredPane.add(nextLevel, JLayeredPane.PALETTE_LAYER);

        this.add(layeredPane);


    }

    public Paddle getPaddle() {
        return paddle;
    }

    public int getGameState() {
        return gameState;
    }

    public void setGameState(int gameState) {
        this.gameState = gameState;
    }

    public int getPlayState() {
        return playState;
    }

    public int getPauseState() {
        return pauseState;
    }

    public int getLevelEndState() {
        return levelEndState;
    }

    public int getLevelFailedState() {
        return levelFailedState;
    }

    public boolean isLevelEnd() {
        return levelEnd;
    }

    public void setLevelEnd(boolean levelEnd) {
        this.levelEnd = levelEnd;
    }

    public boolean getLevelEnd() {
        return levelEnd;
    }

    public boolean getGameOver() {
        return gameOver;
    }

    public Level getCurrentLevel() {
        return currentLevel;
    }

    public void setCurrentLevel(LevelOne currentLevel) {
        this.currentLevel = currentLevel;
    }

    public Ball getBall() {
        return ball;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }

    public int getScreenWidth() {
        return screenWidth;
    }

    public int getScreenHeight() {
        return screenHeight;
    }

    public int getTileSize() {
        return tileSize;
    }

    
   
  
}
