package brickbreakergame;

import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class BrickBreakerGame {
    
    public static void main(String[] args) {
        JFrame window = new JFrame();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false);
        window.setTitle("Brick Breaker Game");
        
        window.setLocation(100,100);
        window.setVisible(true);
        Scanner scan = new Scanner(System.in);
////        TwoPlayerGamePanel twogame = new TwoPlayerGamePanel();
////        window.add(twogame);
////        window.pack();
////        
////        twogame.startGameThread();
//         GamePanel game = new GamePanel();
//        window.add(game);
//        window.pack();
//        game.startGameThread();
      SwingUtilities.invokeLater(() -> new MainMenu());
     // new LevelMenu();
     
    
     //new LevelOne(game,6,11);
     
         
        
    }
    
}
