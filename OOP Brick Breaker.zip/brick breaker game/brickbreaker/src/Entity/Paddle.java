
package Entity;

import brickbreakergame.GamePanel;
import brickbreakergame.KeyHandler;
import brickbreakergame.TwoPlayerGamePanel;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Paddle extends levelEntity {
    GamePanel gp;
    TwoPlayerGamePanel twogp;
    KeyHandler keyH;
   
    final private int platformSpeed = 4;
    private BufferedImage display;

    public Paddle(GamePanel gp, KeyHandler keyH) {
        this.gp = gp;
        this.keyH = keyH;
        setDefaultValues();
        getPaddleImage();
    }

    public void getPaddleImage() {
        try {
            display = ImageIO.read(getClass().getResourceAsStream("/images/paddle.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setDefaultValues() {
        x = 150;
        y = 550;
        width = gp.getTileSize() * 3 / 2;
        height = gp.getTileSize() / 6;
    }

    public void update() {
        if (keyH.rightPressed || keyH.dPressed) {
            if (x >= gp.getScreenWidth() - width) {
                x = gp.getScreenWidth() - width;
            } else {
                x += platformSpeed;
            }
            System.out.println("Moving right: " + x);

        } else if (keyH.leftPressed || keyH.aPressed) {
            if (x <= 0) {
                x = 0;
            } else {
                x -= platformSpeed;
            }
            System.out.println("Moving left: " + x);
        }
    }

    public void draw(Graphics2D g2) {
        BufferedImage image = display;
        g2.drawImage(image, x, y, width, height, null);
    }

    public int getPlatformX() {
        return x;
    }

    public void setPlatformX(int platformX) {
        this.x = platformX;
    }

    public int getPlatformY() {
        return y;
    }

    public void setPlatformY(int platformY) {
        this.y = platformY;
    }

    public int getPlatformWidth() {
        return width;
    }

    public int getPlatformHeight() {
        return height;
    }
    
    // Get the bounds of the paddle
    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }
   
     public void resetpaddle(){
         x = 150;
        y = 550;
        width = gp.getTileSize() * 3 / 2;
        height = gp.getTileSize() / 6;        

     }

}
