package Entity;

import brickbreakergame.GamePanel;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Ball extends levelEntity {
    private GamePanel gp;
    private int ballX = 350;
    private int ballY = 430;
    private int ballXdir = -1;
    private int ballYdir = -2;
    Paddle paddle;
    private int lives = 3;
    private BufferedImage display;
    private BufferedImage live;

    public Ball(GamePanel gp) {
        this.gp = gp;
        getBallImage();
    }

    public int getBallX() {
        return ballX;
    }

    public int getBallY() {
        return ballY;
    }

    public void setBallXdir(int ballXdir) {
        this.ballXdir = ballXdir;
    }

    public void setBallYdir(int ballYdir) {
        this.ballYdir = ballYdir;
    }

    public int getBallXdir() {
        return ballXdir;
    }

    public int getBallYdir() {
        return ballYdir;
    }

    public void draw(Graphics2D g2) {
        g2.drawImage(display, ballX, ballY, 20, 20, null);
        
    }

    private void getBallImage() {
        try {
            display = ImageIO.read(getClass().getResourceAsStream("/images/ball.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
      
    public  BufferedImage getHeartImage() {
        try {
            live = ImageIO.read(getClass().getResourceAsStream("/images/heart.png")); // Load heart image
        } catch (IOException e) {
            e.printStackTrace();
        }
         return live;
    }
    
   
    public void update() {
       
        ballX += ballXdir;
        ballY += ballYdir;

        // Handle ball collision with walls...
        if (ballX < 0 || ballX > gp.getScreenWidth() - 20) {
            ballXdir = -ballXdir;
        }
        if (ballY < 0) {
            ballYdir = -ballYdir;
        }

        // Check if ball falls below the screen
       if (ballY + ballYdir > gp.getScreenHeight() - 20) {
        lives--;
       resetBall();
       //paddle.resetpaddle();
        }

        // Check if no lives are left
        if (lives == 0) {
            gp.setGameOver(true);
        }
    }

    public int getLives() {
        return lives;
    }

    public Rectangle getBounds() {
        return new Rectangle(ballX, ballY, 20, 20);
    }
    
    public void resetBall() {
    ballX = 350; 
    ballY = 430; 
    ballXdir = -1;
    ballYdir = -2;
}
}


