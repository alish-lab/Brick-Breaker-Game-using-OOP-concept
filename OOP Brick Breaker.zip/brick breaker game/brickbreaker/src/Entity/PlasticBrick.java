package Entity;

import brickbreakergame.GamePanel;

public class PlasticBrick extends Brick {
    public PlasticBrick(GamePanel gp, int x, int y) {
        super(gp, x, y,  gp.getTileSize(), gp.getTileSize() / 2, "/images/plastic1.jpeg"); 
    }
}
