

package Entity;

import brickbreakergame.GamePanel;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.IOException;
import javax.imageio.ImageIO;

public class WoodBrick extends Brick {
    private int hitCount;

    public WoodBrick(GamePanel gp, int x, int y) {
        super(gp, x, y, gp.getTileSize(), gp.getTileSize() / 2, "/images/woodbrick.png");
        hitCount = 0;
    }

    @Override
    public void draw(Graphics2D g) {
        if (!isBroken()) {
            g.drawImage(image, x, y, getBrickWidth(), getBrickHeight(), null); 
        }
    }

    @Override
    public void breakBrick() {
        hitCount++;
        if (hitCount >= 2) {
            super.breakBrick();
        }
    }
}
