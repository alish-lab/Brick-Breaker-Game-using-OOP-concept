package Entity;

import brickbreakergame.GamePanel;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Brick extends levelEntity {
    private GamePanel gp;
    private int brickWidth;
    private int brickHeight;
    private int value;
    private boolean broken;
    protected Image image;

    public Brick(GamePanel gp, int x, int y, int width, int height, String imagePath) {
        this.gp = gp;
        this.x = x;
        this.y = y;
        this.brickWidth = width;
        this.brickHeight = height;
        this.value = 1;
        this.broken = false;
        BrickImage(imagePath);
    }

    private void BrickImage(String imagePath) {
        try {
            image = ImageIO.read(getClass().getResourceAsStream(imagePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void draw(Graphics2D g) {
        if (!broken) {
      
            g.drawImage(image,x, y, brickWidth, brickHeight,null); // Use actual width and height
        }
       
    }

    public boolean isBroken() {
        return broken;
    }

    public void breakBrick() {
        broken = true;
    }

    public int getBrickValue() {
        return value;
    }
    
      public Rectangle getBounds() {
        return new Rectangle(x, y, brickWidth, brickHeight);
    }

    public int getBrickWidth() {
        return brickWidth;
    }

    public int getBrickHeight() {
        return brickHeight;
    }

    public void setBroken(boolean broken) {
        this.broken = broken;
    }
      
      
      
}
