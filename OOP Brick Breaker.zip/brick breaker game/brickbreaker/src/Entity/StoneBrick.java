package Entity;

import brickbreakergame.GamePanel;

public class StoneBrick extends Brick {
    public StoneBrick(GamePanel gp, int x, int y) {
        super(gp, x, y, gp.getTileSize(), gp.getTileSize() / 2, "/images/stonebrick.jpeg"); 
        

    }
    
    @Override
    public void breakBrick() {
        // Stone brick doesn't break
    }
}
    
